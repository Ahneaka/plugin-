<?php

echo "hides the admin";